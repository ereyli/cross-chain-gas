import type { Asset, ChainKey } from '../types';

interface PriceCache {
  price: number;
  timestamp: number;
}

const priceCache = new Map<string, PriceCache>();

const PRICE_TTL = parseInt(process.env.PRICE_TTL || '90') * 1000; // Convert to milliseconds

export async function getUsdPrice(asset: Asset, chainKey: ChainKey): Promise<number> {
  // USDC and USDT are always $1
  if (asset === 'USDC' || asset === 'USDT') {
    return 1.0;
  }
  
  if (asset === 'ETH') {
    return getEthPrice();
  }
  
  throw new Error(`Unsupported asset: ${asset}`);
}

async function getEthPrice(): Promise<number> {
  const cacheKey = 'ETH_USD';
  const cached = priceCache.get(cacheKey);
  
  // Return cached price if still valid
  if (cached && Date.now() - cached.timestamp < PRICE_TTL) {
    return cached.price;
  }
  
  try {
    // Fetch from CoinGecko
    const response = await fetch(
      'https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd',
      {
        headers: {
          'Accept': 'application/json',
        },
      }
    );
    
    if (!response.ok) {
      throw new Error(`CoinGecko API error: ${response.status}`);
    }
    
    const data = await response.json();
    const price = data.ethereum?.usd;
    
    if (typeof price !== 'number' || price <= 0) {
      throw new Error('Invalid price data from CoinGecko');
    }
    
    // Cache the price
    priceCache.set(cacheKey, {
      price,
      timestamp: Date.now(),
    });
    
    return price;
  } catch (error) {
    // If we have a cached price (even if expired), use it as fallback
    if (cached) {
      console.warn('Using expired ETH price due to fetch error:', error);
      return cached.price;
    }
    
    throw new Error(`Failed to fetch ETH price: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export function usdToWeiOnTarget(usdAmount: number, ethUsdPrice: number): bigint {
  const ethAmount = usdAmount / ethUsdPrice;
  return BigInt(Math.floor(ethAmount * 1e18));
}

export function weiToUsd(weiAmount: bigint, ethUsdPrice: number): number {
  const ethAmount = Number(weiAmount) / 1e18;
  return ethAmount * ethUsdPrice;
}

export function getTokenDecimals(asset: Asset): number {
  switch (asset) {
    case 'ETH':
      return 18;
    case 'USDC':
      return 6;
    case 'USDT':
      return 6;
    default:
      throw new Error(`Unknown asset: ${asset}`);
  }
}

export function parseTokenAmount(amount: string, asset: Asset): bigint {
  const decimals = getTokenDecimals(asset);
  const factor = BigInt(10 ** decimals);
  const floatAmount = parseFloat(amount);
  return BigInt(Math.floor(floatAmount * Number(factor)));
}

export function formatTokenAmount(amount: bigint, asset: Asset): string {
  const decimals = getTokenDecimals(asset);
  const factor = BigInt(10 ** decimals);
  const formatted = Number(amount) / Number(factor);
  return formatted.toFixed(decimals === 18 ? 6 : decimals);
}

// Clear expired cache entries periodically
export function cleanPriceCache(): void {
  const now = Date.now();
  for (const [key, cache] of priceCache.entries()) {
    if (now - cache.timestamp > PRICE_TTL * 2) { // Clean entries older than 2x TTL
      priceCache.delete(key);
    }
  }
}

// Run cache cleanup every 5 minutes
if (typeof setInterval !== 'undefined') {
  setInterval(cleanPriceCache, 5 * 60 * 1000);
}
